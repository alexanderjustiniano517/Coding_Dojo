import java.util.ArrayList;

public class CafeUtil {

    public int getStreakGoal() {

        int total = 0;
        for(int numWeeks = 1; numWeeks <= 10; numWeeks++) {

            total+= numWeeks;
        }

        return total;
    }
    
    public double getOrderTotal(double[] lineItems) {
        
        double total = 0;
        
        for (double cost: lineItems) {
            total+= cost;
        }
        
        return total;
    }
    
        public void displayMenu(ArrayList<String> menuItems) {
    
            for (int num = 0; num < menuItems.size(); num++) {

                System.out.printf("%s %s \n", num, menuItems.get(num));
            }

        }
    
    public void addCustomer(ArrayList<String> customerList) {

        System.out.println("\nPlease enter your name:");

        String userName = System.console().readLine();

        System.out.printf("\nHello, %s! ", userName);

        System.out.printf("\nThere are %s people ahead of you.\n", customerList.size());

        customerList.add(userName);

        System.out.println(customerList);
    }
}